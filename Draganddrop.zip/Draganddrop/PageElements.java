package codeChallange;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageElements {
@FindBy(id="box1")
public static WebElement oslo;

@FindBy(id="box2")
public static WebElement stockholm;

@FindBy(id="box3")
public static WebElement washington;

@FindBy(id="box4")
public static WebElement copenhagen;

@FindBy(id="box5")
public static WebElement seoul; 

@FindBy(id="box6")
public static WebElement rome; 

@FindBy(id="box7")
public static WebElement madrid; 

//country
@FindBy(id="box101")
public static WebElement norway; 

@FindBy(id="box102")
public static WebElement sweden; 

@FindBy(id="box103")
public static WebElement unitedstates;
 
@FindBy(id="box104")
public static WebElement denmark;
    
@FindBy(id="box105")
 public static WebElement southkorea;
   
@FindBy(id="box106")
 public static WebElement italy ;
  
@FindBy(id="box107")
 public static WebElement spain;
  
@FindBy(id="dropContent")
public static WebElement capitalArea;
}
