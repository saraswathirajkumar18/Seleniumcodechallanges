Summary:
1.first i created PageElements.java file to store web elements.
2.In DragDropChallange.java file , i perform these operations:drag and drop,verfying dropped elements background color and plact it back.
3.Using DrageleParameter.xml ,i passed the parameter inputs for browser setup and mentioned class wants to execute.